from setuptools import setup, find_packages

setup(
    name='bachelor_project',
    version='1.0.0'
)